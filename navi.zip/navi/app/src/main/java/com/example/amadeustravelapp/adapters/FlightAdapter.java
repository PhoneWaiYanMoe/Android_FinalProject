package com.example.amadeustravelapp.adapters;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.amadeustravelapp.R;
import com.example.amadeustravelapp.activities.TicketPurchaseListener;
import com.example.amadeustravelapp.activities.UserProfileActivity;
import com.example.amadeustravelapp.classes.Flight;
import com.example.amadeustravelapp.receivers.AlarmReceiver;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FlightAdapter extends RecyclerView.Adapter<FlightAdapter.FlightViewHolder> {

    private List<Flight> flightList;
    private Context context;
    private TicketPurchaseListener ticketPurchaseListener;

    public FlightAdapter(List<Flight> flightList, Context context, TicketPurchaseListener listener) {
        this.flightList = flightList;
        this.context = context;
        this.ticketPurchaseListener = listener;
    }

    @NonNull
    @Override
    public FlightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.flight_item, parent, false);
        return new FlightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FlightViewHolder holder, int position) {
        Flight flight = flightList.get(position);
        holder.flightNumber.setText("Flight: " + flight.getFlightNumber());
        holder.departureAirport.setText("From: " + flight.getDepartureAirport());
        holder.arrivalAirport.setText("To: " + flight.getArrivalAirport());
        holder.airlineName.setText("Airline: " + flight.getAirlineName());
        holder.duration.setText("Duration: " + flight.getDuration());
        holder.departureTime.setText("Departure Time: " + flight.getDepartureTime());
        holder.arrivalTime.setText("Arrival Time: " + flight.getArrivalTime());
        holder.price.setText("Price: " + flight.getEstimatedPrice());

        holder.purchaseTicketButton.setOnClickListener(v -> showPaymentDialog(flight));
    }

    @Override
    public int getItemCount() {
        return flightList.size();
    }

    static class FlightViewHolder extends RecyclerView.ViewHolder {
        TextView flightNumber, departureAirport, arrivalAirport, airlineName, duration, price, departureTime, arrivalTime;
        Button purchaseTicketButton;

        public FlightViewHolder(@NonNull View itemView) {
            super(itemView);
            flightNumber = itemView.findViewById(R.id.flight_number);
            departureAirport = itemView.findViewById(R.id.departure_airport);
            arrivalAirport = itemView.findViewById(R.id.arrival_airport);
            airlineName = itemView.findViewById(R.id.airlineName);
            duration = itemView.findViewById(R.id.duration);
            price = itemView.findViewById(R.id.price);
            departureTime = itemView.findViewById(R.id.departureTime);
            arrivalTime = itemView.findViewById(R.id.arrivalTime);
            purchaseTicketButton = itemView.findViewById(R.id.purchase_ticket_button);
        }
    }

    private void showPaymentDialog(Flight flight) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Payment Plan");

        LayoutInflater inflater = LayoutInflater.from(context);
        View paymentView = inflater.inflate(R.layout.dialog_payment, null);
        builder.setView(paymentView);

        EditText cardNumber = paymentView.findViewById(R.id.card_number);
        EditText cardExpiry = paymentView.findViewById(R.id.card_expiry);
        EditText cardCVC = paymentView.findViewById(R.id.card_cvc);
        Button confirmPaymentButton = paymentView.findViewById(R.id.confirm_payment_button);

        confirmPaymentButton.setOnClickListener(v -> {
            String cardNum = cardNumber.getText().toString().trim();
            String expiry = cardExpiry.getText().toString().trim();
            String cvc = cardCVC.getText().toString().trim();

            // Validate input
            if (cardNum.isEmpty() || expiry.isEmpty() || cvc.isEmpty()) {
                Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Process the payment
            processPayment(flight, cardNum, expiry, cvc);
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void processPayment(Flight flight, String cardNumber, String expiry, String cvc) {
        // Simulate payment processing
        String ticketDetails = "Flight Number: " + flight.getFlightNumber() +
                "\nFrom: " + flight.getDepartureAirport() +
                "\nTo: " + flight.getArrivalAirport() +
                "\nAirline: " + flight.getAirlineName() +
                "\nDeparture Time: " + flight.getDepartureTime() +
                "\nArrival Time: " + flight.getArrivalTime() +
                "\nDuration: " + flight.getDuration() +
                "\nPrice: " + flight.getEstimatedPrice();

        // Save the ticket details to Firebase
        DatabaseReference ticketsRef = FirebaseDatabase.getInstance().getReference("users")
                .child(FirebaseAuth.getInstance().getCurrentUser ().getUid())
                .child("tickets").push(); // Create a new ticket entry
        ticketsRef.setValue(ticketDetails).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Notify the listener that a ticket was purchased
                if (ticketPurchaseListener != null) {
                    ticketPurchaseListener.onTicketPurchased();
                }
                Toast.makeText(context, "Ticket purchased successfully!", Toast.LENGTH_SHORT).show();

                // Show notification for the purchased ticket
                showNotification("Your ticket for flight " + flight.getFlightNumber() + " has been purchased successfully!");

                // Set an alarm for 12 hours before the flight departure
                setAlarmForFlight(flight, ticketDetails);
            } else {
                // Handle the error
                Toast.makeText(context, "Failed to purchase ticket.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setAlarmForFlight(Flight flight, String ticketDetails) {
        String departureTimeString = flight.getDepartureTime(); // Example: "2024-12-17 18:00"

        Log.d("AlarmDebug", "Departure Time String: " + departureTimeString);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        try {
            Date departureDate = sdf.parse(departureTimeString);
            if (departureDate == null) {
                Log.e("AlarmDebug", "Parsed date is null");
                return;
            }

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(departureDate);
            calendar.add(Calendar.HOUR_OF_DAY, -6); // Set to 12 hours before

            Log.d("AlarmDebug", "Alarm set for: " + calendar.getTime());

            // Set the alarm using AlarmReceiver
            AlarmReceiver.setAlarm(context, calendar.getTimeInMillis(), ticketDetails);
        } catch (ParseException e) {
            Log.e("AlarmDebug", "ParseException: " + e.getMessage());
            Toast.makeText(context, "Error parsing departure time.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("AlarmDebug", "Exception: " + e.getMessage());
            Toast.makeText(context, "Error setting alarm for flight.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showNotification(String message) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "FlightTicketChannel")
                .setSmallIcon(R.drawable.notification) // Replace with your notification icon
                .setContentTitle("Flight Ticket Purchased")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        // Create an intent that will be fired when the user taps the notification
        Intent intent = new Intent(context, UserProfileActivity.class); // Change to your desired activity
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        builder.setContentIntent(pendingIntent);

        // Show the notification
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            // Create notification channel if necessary
            createNotificationChannel(notificationManager);
            notificationManager.notify(1, builder.build());
        }
    }

    private void createNotificationChannel(NotificationManager notificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "FlightTicketChannel",
                    "Flight Ticket Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Channel for flight ticket purchase notifications");
            notificationManager.createNotificationChannel(channel);
        }
    }
}
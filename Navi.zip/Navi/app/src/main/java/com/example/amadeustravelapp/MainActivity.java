package com.example.amadeustravelapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser ;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private EditText fromLocation, toLocation;
    private Button searchButton;
    private RecyclerView recyclerView, popularDestinationsRecyclerView, recommendedDestinationsRecyclerView;
    private FlightAdapter flightAdapter;
    private PopularDestinationsAdapter destinationsAdapter;
    private RecommendedDestinationsAdapter recommendedDestinationsAdapter;
    private List<Flight> flightList;
    private List<Destination> destinationsList;
    private List<Destination> recommendedDestinationsList;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private FusedLocationProviderClient fusedLocationClient;
    private static final String NINJA_API_KEY = "3hHhaYzZUi1nUynWhO78Ew==gGlPJGuHMvcvagee"; // Ninja API key
    private static final String FLIGHT_API_KEY = "0fe9c907ac156a0825f1a8aa47eb52ee"; // Replace with your flight API key
    private static final String TAG = "MainActivity";
    private GoogleMap googleMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fromLocation = findViewById(R.id.from_location);
        toLocation = findViewById(R.id.to_location);
        searchButton = findViewById(R.id.search_button);
        recyclerView = findViewById(R.id.recycler_view);
        popularDestinationsRecyclerView = findViewById(R.id.popular_destinations_recycler);
        recommendedDestinationsRecyclerView = findViewById(R.id.recommended_destinations_recycler);

        flightList = new ArrayList<>();
        destinationsList = new ArrayList<>();
        recommendedDestinationsList = new ArrayList<>();

        flightAdapter = new FlightAdapter(flightList);
        destinationsAdapter = new PopularDestinationsAdapter(this, destinationsList);
        recommendedDestinationsAdapter = new RecommendedDestinationsAdapter(this, recommendedDestinationsList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(flightAdapter);

        popularDestinationsRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        popularDestinationsRecyclerView.setAdapter(destinationsAdapter);

        recommendedDestinationsRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recommendedDestinationsRecyclerView.setAdapter(recommendedDestinationsAdapter);

        searchButton.setOnClickListener(v -> {
            String fromCity = fromLocation.getText().toString().trim();
            String toCity = toLocation.getText().toString().trim();
            if (!fromCity.isEmpty() && !toCity.isEmpty()) {
                try {
                    fetchAirportCodesAndSearchFlights(fromCity, toCity);
                } catch (UnsupportedEncodingException e) {
                    Log.e(TAG, "Error encoding city names", e);
                    Toast.makeText(this, "Error processing city names", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter both departure and arrival cities", Toast.LENGTH_SHORT).show();
            }
        });
        // Initialize Google Maps
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map_fragment);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        } else {
            Log.e(TAG, "Map fragment is null");
        }

        // Fetch popular destinations from Firebase
        fetchPopularDestinations();

        // Fetch recommended destinations based on user's favorite places
        fetchRecommendedDestinations();
    }


    private void fetchPopularDestinations() {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("places/places");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                destinationsList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Destination destination = dataSnapshot.getValue(Destination.class);
                    if (destination != null) {
                        destinationsList.add(destination);
                        Log.d(TAG, "Fetched popular destination: " + destination.getTitle());
                    }
                }
                destinationsAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Firebase database error: " + error.getMessage());
                Toast.makeText(MainActivity.this, "Failed to load popular destinations.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchRecommendedDestinations() {
        FirebaseUser  user = FirebaseAuth.getInstance().getCurrentUser ();
        if (user != null) {
            String userId = user.getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(userId).child("favoritePlaces");

            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    recommendedDestinationsList.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        String placeTitle = dataSnapshot.getValue(String.class); // Assuming the value is the place title
                        fetchDestinationByTitle(placeTitle);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.e(TAG, "Firebase database error: " + error.getMessage());
                    Toast.makeText(MainActivity.this, "Failed to load recommended destinations.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void fetchDestinationByTitle(String placeTitle) {
        DatabaseReference placesRef = FirebaseDatabase.getInstance().getReference("places/places");
        placesRef.orderByChild("title").equalTo(placeTitle).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Destination destination = dataSnapshot.getValue(Destination.class);
                    if (destination != null) {
                        recommendedDestinationsList.add(destination);
                        Log.d(TAG, "Fetched recommended destination: " + destination.getTitle());
                    }
                }
                // Notify the adapter that the data has changed
                recommendedDestinationsAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error fetching destination by title: " + error.getMessage());
            }
        });

    }
    private void fetchAirportCode(RequestQueue queue, String cityName, AirportCodeCallback callback) throws UnsupportedEncodingException {
        String url = "https://api.api-ninjas.com/v1/airports?name=" + URLEncoder.encode(cityName, "UTF-8");
        Log.d(TAG, "Fetching IATA code for URL: " + url);

        // Create a JsonArrayRequest with headers
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    Log.d(TAG, "Ninja API Response: " + response.toString());
                    try {
                        if (response.length() > 0) {
                            JSONObject airportData = response.getJSONObject(0);
                            String iataCode = airportData.getString("iata");
                            Log.d(TAG, "IATA Code for " + cityName + ": " + iataCode);
                            callback.onCodeReceived(iataCode);
                        } else {
                            Toast.makeText(this, "No airport found for: " + cityName, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "Error parsing airport data for: " + cityName, e);
                        try {
                            callback.onCodeReceived(null);
                        } catch (UnsupportedEncodingException ex) {
                            throw new RuntimeException(ex);
                        }
                    } catch (UnsupportedEncodingException e) {
                        throw new RuntimeException(e);
                    }
                },
                error -> {
                    Log.e(TAG, "Error fetching airport code for: " + cityName, error);
                    if (error.networkResponse != null) {
                        String errorMessage = new String(error.networkResponse.data);
                        Log.e(TAG, "Error response: " + errorMessage);
                    }
                    try {
                        callback.onCodeReceived(null);
                    } catch (UnsupportedEncodingException e) {
                        throw new RuntimeException(e);
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("X-Api-Key", NINJA_API_KEY); // Add your Ninja API key here
                return headers;
            }
        };

        queue.add(request);
    }

    private void fetchAirportCodesAndSearchFlights(String fromCity, String toCity) throws UnsupportedEncodingException {
        RequestQueue queue = Volley.newRequestQueue(this);

        fetchAirportCode(queue, fromCity, fromCode -> {
            Log.d(TAG, "From Code: " + fromCode);
            fetchAirportCode(queue, toCity, toCode -> {
                Log.d(TAG, "To Code: " + toCode);
                if (fromCode != null && !fromCode.isEmpty() && toCode != null && !toCode.isEmpty()) {
                    searchFlights(fromCode, toCode);
                } else {
                    Toast.makeText(this, "Could not find IATA codes for the provided cities.", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }
    private void searchFlights(String fromCode, String toCode) {
        String url = "http://api.aviationstack.com/v1/flights?access_key=" + FLIGHT_API_KEY + "&dep_iata=" + fromCode + "&arr_iata=" + toCode;
        Log.d(TAG, "Searching flights with URL: " + url);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    Log.d(TAG, "Flight API Response: " + response.toString()); // Log the full response
                    try {
                        JSONArray flights = response.getJSONArray("data");
                        flightList.clear();
                        if (flights.length() == 0) {
                            Toast.makeText(this, "No flights found for the selected route.", Toast.LENGTH_SHORT).show();
                        } else {
                            for (int i = 0; i < flights.length(); i++) {
                                JSONObject flight = flights.getJSONObject(i);
                                String flightNumber = flight.getJSONObject("flight").getString("number");
                                String departureAirport = flight.getJSONObject("departure").getString("airport");
                                String arrivalAirport = flight.getJSONObject("arrival").getString("airport");
                                String airlineName = flight.optJSONObject("airline") != null ? flight.getJSONObject("airline").optString("name", "N/A") : "N/A";

                                // Get scheduled departure and arrival times
                                String scheduledDeparture = flight.getJSONObject("departure").getString("scheduled");
                                String scheduledArrival = flight.getJSONObject("arrival").getString("scheduled");
                                // Format date and time
                                String formattedDeparture = formatDateTime(scheduledDeparture);
                                String formattedArrival = formatDateTime(scheduledArrival);

                                // Log the scheduled times
                                Log.d(TAG, "Scheduled Departure: " + scheduledDeparture);
                                Log.d(TAG, "Scheduled Arrival: " + scheduledArrival);

                                // Calculate flight duration (string)
                                String duration = calculateDuration(scheduledDeparture, scheduledArrival);

// Extract minutes from duration
                                long durationInMinutes = extractMinutesFromDuration(duration);
// Calculate estimated price
                                double estimatedPrice = calculateEstimatedPrice(durationInMinutes);
                                String formattedPrice = String.format("%.2f $", estimatedPrice);
                                // Create Flight object with the duration as a string
                                Flight flightData = new Flight(flightNumber, departureAirport, arrivalAirport, airlineName, duration,formattedPrice,formattedDeparture, formattedArrival);
                                flightList.add(flightData);
                            }
                            flightAdapter.notifyDataSetChanged();
                            Toast.makeText(this, "Flights fetched successfully!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "Error parsing flight data", e);
                        Toast.makeText(this, "Error parsing flight data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e(TAG, "Error fetching flights", error);
                    if (error.networkResponse != null) {
                        String errorMessage = new String(error.networkResponse.data);
                        Log.e(TAG, "Error response: " + errorMessage);
                    } else {
                        Log.e(TAG, "Network error: " + error.getMessage());
                    }
                    Toast.makeText(this, "Error fetching flights. Please try again later.", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(this).add(request);
    }

    private String calculateDuration(String departureTime, String arrivalTime) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.getDefault());
            Date departureDate = format.parse(departureTime);
            Date arrivalDate = format.parse(arrivalTime);

            if (departureDate != null && arrivalDate != null) {
                long durationMillis = arrivalDate.getTime() - departureDate.getTime();
                long hours = (durationMillis / (1000 * 60 * 60));
                long minutes = (durationMillis / (1000 * 60)) % 60;
                return hours + " hours and " + minutes + " minutes";
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error parsing date", e);
        }
        return "Duration unavailable"; // Fallback for parsing errors
    }

    private double calculateEstimatedPrice(long durationInMinutes) {
        double basePrice = 100.0; // Base price in dollars
        double pricePerHour = 50.0; // Price per hour in dollars

        // Convert duration from minutes to hours
        double durationInHours = durationInMinutes / 60.0;

        // Calculate estimated price
        return basePrice + (durationInHours * pricePerHour);
    }
    private long extractMinutesFromDuration(String duration) {
        long hours = 0, minutes = 0;

        // Extract hours
        Pattern hoursPattern = Pattern.compile("(\\d+) hours");
        Matcher hoursMatcher = hoursPattern.matcher(duration);
        if (hoursMatcher.find()) {
            hours = Long.parseLong(hoursMatcher.group(1));
        }

        // Extract minutes
        Pattern minutesPattern = Pattern.compile("(\\d+) minutes");
        Matcher minutesMatcher = minutesPattern.matcher(duration);
        if (minutesMatcher.find()) {
            minutes = Long.parseLong(minutesMatcher.group(1));
        }

        return hours * 60 + minutes;
    }

    // Helper method to format date and time
    private String formatDateTime(String dateTime) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            Date date = inputFormat.parse(dateTime);
            if (date != null) {
                return outputFormat.format(date);
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error parsing date", e);
        }
        return "Unavailable";
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        this.googleMap = map; // Assign the map instance to the class variable

        // Check for location permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Request permissions
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        // If permissions are granted, get the current location
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                            googleMap.addMarker(new MarkerOptions().position(userLocation).title("Your Location"));
                            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15));
                        } else {
                            Log.e(TAG, "Location is null");
                        }
                    }
                });

        // Enable the My Location layer
        googleMap.setMyLocationEnabled(true);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults); // Call the super method
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, initialize the map again
                onMapReady(googleMap); // You need to pass the GoogleMap instance here
            } else {
                Toast.makeText(this, "Location permission is required to show your current location", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.user_menu) { // Check for user_menu ID
            showUserMenu();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void showUserMenu() {
        PopupMenu popupMenu = new PopupMenu(this, findViewById(R.id.toolbar));
        popupMenu.getMenuInflater().inflate(R.menu.user_menu, popupMenu.getMenu());

        FirebaseUser  user = FirebaseAuth.getInstance().getCurrentUser ();
        if (user != null) {
            String userName = user.getDisplayName();
            popupMenu.getMenu().getItem(0).setTitle(userName != null && !userName.isEmpty() ? userName : user.getEmail());
        } else {
            popupMenu.getMenu().getItem(0).setTitle("User ");
        }

        popupMenu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.logout) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                return true;
            } else if (item.getItemId() == R.id.user_profile) { // Assuming you have a user_profile item in your menu
                Intent intent = new Intent(MainActivity.this, UserProfileActivity.class);
                startActivity(intent);
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

}
interface AirportCodeCallback {
    void onCodeReceived(String iataCode) throws UnsupportedEncodingException;
}


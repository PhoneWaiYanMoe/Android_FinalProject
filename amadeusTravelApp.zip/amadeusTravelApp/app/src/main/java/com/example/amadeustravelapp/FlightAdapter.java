package com.example.amadeustravelapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FlightAdapter extends RecyclerView.Adapter<FlightAdapter.FlightViewHolder> {

    private List<Flight> flightList;

    public FlightAdapter(List<Flight> flightList) {
        this.flightList = flightList;
    }

    @NonNull
    @Override
    public FlightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.flight_item, parent, false);
        return new FlightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FlightViewHolder holder, int position) {
        Flight flight = flightList.get(position);
        holder.flightNumber.setText("Flight: " + flight.getFlightNumber());
        holder.departureAirport.setText("From: " + flight.getDepartureAirport());
        holder.arrivalAirport.setText("To: " + flight.getArrivalAirport());
        holder.date.setText("Date: " + flight.getDate());
    }

    @Override
    public int getItemCount() {
        return flightList.size();
    }

    static class FlightViewHolder extends RecyclerView.ViewHolder {
        TextView flightNumber, departureAirport, arrivalAirport, date;

        public FlightViewHolder(@NonNull View itemView) {
            super(itemView);
            flightNumber = itemView.findViewById(R.id.flight_number);
            departureAirport = itemView.findViewById(R.id.departure_airport);
            arrivalAirport = itemView.findViewById(R.id.arrival_airport);
            date = itemView.findViewById(R.id.date);
        }
    }
}

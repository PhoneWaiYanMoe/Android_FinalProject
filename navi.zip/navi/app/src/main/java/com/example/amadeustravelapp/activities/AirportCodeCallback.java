package com.example.amadeustravelapp.activities;

import java.io.UnsupportedEncodingException;

interface AirportCodeCallback {
    void onCodeReceived(String iataCode) throws UnsupportedEncodingException;
}


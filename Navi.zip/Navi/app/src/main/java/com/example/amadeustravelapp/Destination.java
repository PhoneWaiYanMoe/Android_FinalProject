package com.example.amadeustravelapp;

import java.util.List;
import java.util.Map;

public class Destination {
    private String title;       // Matches the "title" key in Firebase
    private String address;     // Matches the "address" key in Firebase
    private double rating;      // Matches the "rating" key in Firebase
    private String description; // Matches the "description" key in Firebase
    private List<String> things_to_do; // Use List<String> for things_to_do
    private String price;       // Matches the "price" key in Firebase
    private String imageUrl;    // Matches the "imageUrl" key in Firebase
    private Map<String, Boolean> bookmarkedBy; // Matches "bookmarkedBy" key
    private Map<String, String> comments;      // Matches "comments" key

    // Default constructor required for Firebase deserialization
    public Destination() {
    }

    public Destination(String title, String address, double rating, String description, List<String> things_to_do, String price, String imageUrl, Map<String, Boolean> bookmarkedBy, Map<String, String> comments) {
        this.title = title;
        this.address = address;
        this.rating = rating;
        this.description = description;
        this.things_to_do = things_to_do;
        this.price = price;
        this.imageUrl = imageUrl;
        this.bookmarkedBy = bookmarkedBy;
        this.comments = comments;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getThings_to_do() {
        return things_to_do;
    }

    public void setThings_to_do(List<String> things_to_do) {
        this.things_to_do = things_to_do;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getBookmarkedBy() {
        return (bookmarkedBy == null || bookmarkedBy.isEmpty()) ? "Empty" : bookmarkedBy.toString();
    }

    public void setBookmarkedBy(Map<String, Boolean> bookmarkedBy) {
        this.bookmarkedBy = bookmarkedBy;
    }

    public String getComments() {
        return (comments == null || comments.isEmpty()) ? "Empty" : comments.toString();
    }

    public void setComments(Map<String, String> comments) {
        this.comments = comments;
    }
}
package com.example.amadeustravelapp.fragments;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.amadeustravelapp.R;
import com.example.amadeustravelapp.activities.LoginActivity;
import com.example.amadeustravelapp.activities.UserProfileActivity;
import com.example.amadeustravelapp.activities.flightSearchActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser ;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SearchFragment extends Fragment {

    private EditText fromLocation, toLocation;
    private Button searchButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        fromLocation = view.findViewById(R.id.from_location);
        toLocation = view.findViewById(R.id.to_location);
        searchButton = view.findViewById(R.id.search_button);

        searchButton.setOnClickListener(v -> {
            String fromCity = fromLocation.getText().toString().trim();
            String toCity = toLocation.getText().toString().trim();
            if (!fromCity.isEmpty() && !toCity.isEmpty()) {
                Intent intent = new Intent(getActivity(), flightSearchActivity.class);
                intent.putExtra("FROM_CITY", fromCity);
                intent.putExtra("TO_CITY", toCity);
                startActivity(intent);
            } else {
                Toast.makeText(getActivity(), "Please enter both departure and arrival cities", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }


}
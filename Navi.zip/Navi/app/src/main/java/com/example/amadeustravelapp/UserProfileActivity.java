package com.example.amadeustravelapp;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class UserProfileActivity extends AppCompatActivity {

    private EditText displayNameEditText, genderEditText, dobEditText;
    private Button saveButton;
    private ListView favoritePlacesListView;
    private FirebaseUser currentUser;
    private DatabaseReference userDatabaseRef;
    private FavoritePlacesAdapter favoritePlacesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        displayNameEditText = findViewById(R.id.displayNameEditText);
        genderEditText = findViewById(R.id.genderEditText);
        dobEditText = findViewById(R.id.dobEditText);
        saveButton = findViewById(R.id.saveButton);
        favoritePlacesListView = findViewById(R.id.favoritePlacesListView);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            userDatabaseRef = FirebaseDatabase.getInstance().getReference("users").child(currentUser.getUid());
            loadUserInfo();
            loadFavoritePlaces();
        }

        // Disable the save button initially
        saveButton.setEnabled(false);

        // Add TextWatcher to enable save button when changes are made
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                saveButton.setEnabled(true); // Enable save button when text changes
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        displayNameEditText.addTextChangedListener(textWatcher);
        genderEditText.addTextChangedListener(textWatcher);
        dobEditText.addTextChangedListener(textWatcher);

        saveButton.setOnClickListener(v -> saveUserInfo());
    }

    private void loadUserInfo() {
        userDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String displayName = snapshot.child("displayName").getValue(String.class);
                    String gender = snapshot.child("gender").getValue(String.class);
                    String dob = snapshot.child("dateOfBirth").getValue(String.class);

                    displayNameEditText.setText(displayName);
                    genderEditText.setText(gender != null ? gender : ""); // Set to empty if null
                    dobEditText.setText(dob != null ? dob : ""); // Set to empty if null
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UserProfileActivity.this, "Failed to load user info", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadFavoritePlaces() {
        userDatabaseRef.child("favoritePlaces").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    List<String> favoritePlaces = new ArrayList<>();
                    List<String> favoritePlacesUrls = new ArrayList<>();
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        String placeName = childSnapshot.getValue(String.class);
                        String placeUrl = childSnapshot.getKey();
                        favoritePlaces.add(placeName);
                        favoritePlacesUrls.add(placeUrl);
                    }

                    favoritePlacesAdapter = new FavoritePlacesAdapter(UserProfileActivity.this, favoritePlaces, favoritePlacesUrls, userDatabaseRef);
                    favoritePlacesListView.setAdapter(favoritePlacesAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UserProfileActivity.this, "Failed to load favorite places", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveUserInfo() {
        String displayName = displayNameEditText.getText().toString().trim();
        String gender = genderEditText.getText().toString().trim();
        String dob = dobEditText.getText().toString().trim();

        if (displayName.isEmpty()) {
            Toast.makeText(this, "Display name must be filled", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save display name
        userDatabaseRef.child("displayName").setValue(displayName);

        // Save gender only if it is not empty
        if (!gender.isEmpty()) {
            userDatabaseRef.child("gender").setValue(gender);
        }

        // Save date of birth only if it is not empty
        if (!dob.isEmpty()) {
            userDatabaseRef.child("dateOfBirth").setValue(dob);
        }

        Toast.makeText(UserProfileActivity.this, "User info updated", Toast.LENGTH_SHORT).show();
        saveButton.setEnabled(false); // Disable save button after saving
    }
}

package com.example.amadeustravelapp.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.amadeustravelapp.R;
import com.example.amadeustravelapp.adapters.PopularDestinationsAdapter;
import com.example.amadeustravelapp.adapters.RecommendedDestinationsAdapter;
import com.example.amadeustravelapp.classes.Destination;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DestinationFragment extends Fragment {

    private static final String TAG = "DestinationsFragment";
    private FirebaseUser currentUser;
    private RecyclerView popularDestinationsRecyclerView;
    private RecyclerView recommendedDestinationsRecyclerView;
    private PopularDestinationsAdapter destinationsAdapter;
    private RecommendedDestinationsAdapter recommendedDestinationsAdapter;
    private List<Destination> destinationsList;
    private List<Destination> recommendedDestinationsList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_destination, container, false);

        // Initialize RecyclerViews
        popularDestinationsRecyclerView = view.findViewById(R.id.popular_destinations_recycler);
        recommendedDestinationsRecyclerView = view.findViewById(R.id.recommended_destinations_recycler);

        // Initialize lists
        destinationsList = new ArrayList<>();
        recommendedDestinationsList = new ArrayList<>();

        // Initialize
        //adapters
        destinationsAdapter = new PopularDestinationsAdapter(getActivity(), destinationsList);
        recommendedDestinationsAdapter = new RecommendedDestinationsAdapter(getActivity(), recommendedDestinationsList);

        //Initialize Firebase
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        // Set up RecyclerViews
        setupRecyclerViews();

        // Fetch popular and recommended destinations
        fetchPopularDestinations();
        fetchRecommendedDestinations();

        return view;
    }

    private void setupRecyclerViews() {
        popularDestinationsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        popularDestinationsRecyclerView.setAdapter(destinationsAdapter);

        recommendedDestinationsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        recommendedDestinationsRecyclerView.setAdapter(recommendedDestinationsAdapter);
    }

    private void fetchPopularDestinations() {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("places/places");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                destinationsList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Destination destination = dataSnapshot.getValue(Destination.class);
                    if (destination != null) {
                        destinationsList.add(destination);
                        Log.d(TAG, "Fetched popular destination: " + destination.getTitle());
                    }
                }
                destinationsAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Firebase database error: " + error.getMessage());
                Toast.makeText(getActivity(), "Failed to load popular destinations.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchRecommendedDestinations() {
        if (currentUser != null) {
            String userId = currentUser.getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(userId).child("favoritePlaces");

            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    recommendedDestinationsList.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        String placeTitle = dataSnapshot.getValue(String.class); // Assuming the value is the place title
                        fetchDestinationByTitle(placeTitle);
                        Log.d(TAG, "onDataChange: " + placeTitle);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.e(TAG, "Firebase database error: " + error.getMessage());
                    Toast.makeText(getActivity(), "Failed to load recommended destinations.", Toast.LENGTH_SHORT).show();
                }
            });
        }


    }

    private void fetchDestinationByTitle(String placeTitle) {
        DatabaseReference placesRef = FirebaseDatabase.getInstance().getReference("places/places");
        placesRef.orderByChild("title").equalTo(placeTitle).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Destination destination = dataSnapshot.getValue(Destination.class);
                    if (destination != null) {
                        recommendedDestinationsList.add(destination);
                        Log.d(TAG, "Fetched recommended destination: " + destination.getTitle());
                    }
                }
                // Notify the adapter that the data has changed
                recommendedDestinationsAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error fetching destination by title: " + error.getMessage());
            }
        });
    }
}
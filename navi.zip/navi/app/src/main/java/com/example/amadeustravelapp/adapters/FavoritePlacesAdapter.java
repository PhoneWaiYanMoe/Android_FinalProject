package com.example.amadeustravelapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.amadeustravelapp.R;
import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class FavoritePlacesAdapter extends ArrayAdapter<String> {

    private final Context context;
    private final List<String> favoritePlaces;
    private final List<String> favoritePlacesUrls;
    private final DatabaseReference userDatabaseRef;

    public FavoritePlacesAdapter(Context context, List<String> favoritePlaces, List<String> favoritePlacesUrls, DatabaseReference userDatabaseRef) {
        super(context, R.layout.favorite_place_item, favoritePlaces);
        this.context = context;
        this.favoritePlaces = favoritePlaces;
        this.favoritePlacesUrls = favoritePlacesUrls;
        this.userDatabaseRef = userDatabaseRef;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.favorite_place_item, parent, false);
        }

        String placeName = favoritePlaces.get(position);
        String placeUrl = favoritePlacesUrls.get(position);

        TextView placeNameTextView = convertView.findViewById(R.id.placeNameTextView);
        Button deleteButton = convertView.findViewById(R.id.deleteButton);

        placeNameTextView.setText(placeName);


        deleteButton.setOnClickListener(v -> {
            userDatabaseRef.child("favoritePlaces").child(placeUrl).removeValue();
            favoritePlaces.remove(position);
            favoritePlacesUrls.remove(position);
            notifyDataSetChanged();
        });

        return convertView;
    }
}
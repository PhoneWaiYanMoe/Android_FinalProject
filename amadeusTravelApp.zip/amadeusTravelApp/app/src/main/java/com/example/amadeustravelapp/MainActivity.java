package com.example.amadeustravelapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap googleMap;
    private EditText fromLocation, toLocation;
    private Button searchButton;
    private RecyclerView recyclerView;
    private FlightAdapter flightAdapter;
    private List<Flight> flightList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
     //   googleMap.setMapStyle(null);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map_fragment);
        mapFragment.getMapAsync(googleMap -> {
            if (googleMap != null) {
                Log.d("Map", "Google Map initialized successfully.");
                googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            } else {
                Log.e("Map", "Failed to initialize Google Map.");
            }
        });


//        // Existing code for flight search
//        fromLocation = findViewById(R.id.from_location);
//        toLocation = findViewById(R.id.to_location);
//        searchButton = findViewById(R.id.search_button);
//        recyclerView = findViewById(R.id.recycler_view);
//
//        flightList = new ArrayList<>();
//        flightAdapter = new FlightAdapter(flightList);
//
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView.setAdapter(flightAdapter);
//
//        searchButton.setOnClickListener(v -> {
//            String from = fromLocation.getText().toString().trim();
//            String to = toLocation.getText().toString().trim();
//
//            if (!from.isEmpty() && !to.isEmpty()) {
//                try {
//                    searchFlights(from, to);
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                }
//            } else {
//                Toast.makeText(this, "Please enter both locations", Toast.LENGTH_SHORT).show();
//            }
//       });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

        // Add a default marker (e.g., center of the map)
        LatLng defaultLocation = new LatLng(55.676098, 12.568337); // San Francisco
        googleMap.addMarker(new MarkerOptions().position(defaultLocation).title("San Francisco"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12));
    }

//    @Override
//    public void onMapReady(GoogleMap map) {
//        googleMap = map;
//
//        // Add a default marker (e.g., center of the map)
//        LatLng defaultLocation = new LatLng(55.676098, 12.568337); // San Francisco
//        googleMap.addMarker(new MarkerOptions().position(defaultLocation).title("San Francisco"));
//        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12));
//    }

//
//    private void searchFlights(String from, String to) throws UnsupportedEncodingException {
//        String url = "http://api.aviationstack.com/v1/flights?access_key=0fe9c907ac156a0825f1a8aa47eb52ee&flight_status=active&dep_iata="
//                + from + "&arr_iata=" + to;
//
//        RequestQueue queue = Volley.newRequestQueue(this);
//
//        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
//                response -> {
//                    try {
//                        JSONArray data = response.getJSONArray("data");
//                        flightList.clear();
//
//                        if (data.length() == 0) {
//                            Toast.makeText(this, "No flights found", Toast.LENGTH_SHORT).show();
//                            return;
//                        }
//
//                        for (int i = 0; i < data.length(); i++) {
//                            JSONObject flightObject = data.getJSONObject(i);
//                            String flightNumber = flightObject.getJSONObject("flight").getString("number");
//                            String departure = flightObject.getJSONObject("departure").getString("airport");
//                            String arrival = flightObject.getJSONObject("arrival").getString("airport");
//                            String date = flightObject.getJSONObject("departure").getString("scheduled");
//
//                            flightList.add(new Flight(flightNumber, departure, arrival, date));
//                        }
//
//                        flightAdapter.notifyDataSetChanged();
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                        Toast.makeText(this, "Error parsing data", Toast.LENGTH_SHORT).show();
//                    }
//                },
//                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
//        );
//
//        queue.add(jsonObjectRequest);
//    }
}



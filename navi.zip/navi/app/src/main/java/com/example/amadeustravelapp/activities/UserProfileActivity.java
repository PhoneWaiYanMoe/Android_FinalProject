package com.example.amadeustravelapp.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.amadeustravelapp.R;
import com.example.amadeustravelapp.adapters.FavoritePlacesAdapter;
import com.example.amadeustravelapp.adapters.FlightAdapter;
import com.example.amadeustravelapp.classes.Flight;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser ;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UserProfileActivity extends AppCompatActivity implements TicketPurchaseListener {

    private TextView displayNameTextView, genderTextView, dobTextView;
    private EditText displayNameEditText, genderEditText, dobEditText;
    private Button saveButton;
    private ListView favoritePlacesListView;
    private ListView ticketsListView;
    private FirebaseUser  currentUser ;
    private DatabaseReference userDatabaseRef;
    private FavoritePlacesAdapter favoritePlacesAdapter;
    private List<Flight> flightList = new ArrayList<>();
    private List<String[]> ticketList = new ArrayList<>(); // Store ticket details

    // Variables to store original values
    private String originalDisplayName;
    private String originalGender;
    private String originalDob;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        displayNameTextView = findViewById(R.id.displayNameTextView);
        genderTextView = findViewById(R.id.genderTextView);
        dobTextView = findViewById(R.id.dobTextView);
        displayNameEditText = findViewById(R.id.displayNameEditText);
        genderEditText = findViewById(R.id.genderEditText);
        dobEditText = findViewById(R.id.dobEditText);
        saveButton = findViewById(R.id.saveButton);
        favoritePlacesListView = findViewById(R.id.favoritePlacesListView);
        ticketsListView = findViewById(R.id.ticketsListView);

        currentUser  = FirebaseAuth.getInstance().getCurrentUser ();
        if (currentUser  != null) {
            userDatabaseRef = FirebaseDatabase.getInstance().getReference("users").child(currentUser .getUid());
            loadUserInfo();
            loadFavoritePlaces();
            loadTickets();
        }

        // Disable the save button initially
        saveButton.setEnabled(false);

        // Set click listeners to switch to EditText
        displayNameTextView.setOnClickListener(v -> switchToEditText(displayNameTextView, displayNameEditText));
        genderTextView.setOnClickListener(v -> switchToEditText(genderTextView, genderEditText));
        dobTextView.setOnClickListener(v -> switchToEditText(dobTextView, dobEditText));

        // Save button click listener
        saveButton.setOnClickListener(v -> saveUserInfo());
    }

    @Override
    public void onTicketPurchased() {
        loadTickets(); // Refresh the tickets when a new ticket is purchased
    }

    private void switchToEditText(TextView textView, EditText editText) {
        // Set the EditText value to the TextView value
        editText.setText(textView.getText());
        textView.setVisibility(View.GONE); // Hide TextView
        editText.setVisibility(View.VISIBLE); // Show EditText
        editText.requestFocus(); // Focus on EditText

        // Add a TextWatcher to enable the save button when changes are made
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                saveButton.setEnabled(s.length() > 0); // Enable save button if there's text
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void loadUserInfo() {
        userDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    originalDisplayName = snapshot.child("displayName").getValue(String.class);
                    originalGender = snapshot.child("gender").getValue(String.class);
                    originalDob = snapshot.child("dateOfBirth").getValue(String.class);

                    displayNameTextView.setText(originalDisplayName);
                    genderTextView.setText(originalGender != null ? originalGender : ""); // Set to empty if null
                    dobTextView.setText(originalDob != null ? originalDob : ""); // Set to empty if null
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UserProfileActivity.this, "Failed to load user info", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadFavoritePlaces() {
        userDatabaseRef.child("favoritePlaces").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    List<String> favoritePlaces = new ArrayList<>();
                    List<String> favoritePlacesUrls = new ArrayList<>();
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        String placeName = childSnapshot.getValue(String.class);
                        String placeUrl = childSnapshot.getKey();
                        favoritePlaces.add(placeName);
                        favoritePlacesUrls.add(placeUrl);
                    }

                    favoritePlacesAdapter = new FavoritePlacesAdapter(UserProfileActivity.this, favoritePlaces, favoritePlacesUrls, userDatabaseRef);
                    favoritePlacesListView.setAdapter(favoritePlacesAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UserProfileActivity.this, "Failed to load favorite places", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveUserInfo() {
        String displayName = displayNameEditText.getText().toString().trim();
        String gender = genderEditText.getText().toString().trim();
        String dob = dobEditText.getText().toString().trim();

        if (displayName.isEmpty()) {
            Toast.makeText(this, "Display name must be filled", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save display name
        userDatabaseRef.child("displayName").setValue(displayName);
        displayNameTextView.setText(displayName); // Update TextView
        displayNameEditText.setVisibility(View.GONE); // Hide EditText
        displayNameTextView.setVisibility(View.VISIBLE); // Show TextView

        // Save gender only if it is not empty
        if (!gender.isEmpty()) {
            userDatabaseRef.child("gender").setValue(gender);
            genderTextView.setText(gender); // Update TextView
            genderEditText.setVisibility(View.GONE); // Hide EditText
            genderTextView.setVisibility(View.VISIBLE); // Show TextView
        }

        // Save date of birth only if it is not empty
        if (!dob.isEmpty()) {
            userDatabaseRef.child("dateOfBirth").setValue(dob);
            dobTextView.setText(dob); // Update TextView
            dobEditText.setVisibility(View.GONE); // Hide EditText
            dobTextView.setVisibility(View.VISIBLE); // Show TextView
        }

        Toast.makeText(UserProfileActivity.this, "User  info updated", Toast.LENGTH_SHORT).show();
        saveButton.setEnabled(false); // Disable save button after saving
    }

    private void loadTickets() {
        userDatabaseRef.child("tickets").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ticketList.clear(); // Clear previous ticket data
                List<String> flightNumbers = new ArrayList<>(); // List to hold flight numbers

                if (snapshot.exists()) {
                    for (DataSnapshot ticketSnapshot : snapshot.getChildren()) {
                        String ticketDetails = ticketSnapshot.getValue(String.class);
                        String[] details = ticketDetails.split("\n");
                        ticketList.add(details); // Store the full ticket details
                        flightNumbers.add(details[0]); // Add flight number to the list
                    }

                    // Set the adapter for the ListView to display flight numbers
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(UserProfileActivity.this,
                            android.R                            .layout.simple_list_item_1, flightNumbers);
                    ticketsListView.setAdapter(adapter);

                    // Set an item click listener to show flight details
                    ticketsListView.setOnItemClickListener((parent, view, position, id) -> {
                        showCustomTicketDialog(ticketList.get(position)); // Show details for the clicked ticket
                    });
                } else {
                    // Handle the case where there are no tickets
                    Toast.makeText(UserProfileActivity.this, "No tickets purchased yet.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UserProfileActivity.this, "Failed to load tickets", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showCustomTicketDialog(String[] details) {
        // Inflate the custom layout
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.ticket_detail_dialog, null);

        // Find views in the dialog layout
        TextView airlineName = dialogView.findViewById(R.id.airlineName);
        TextView date = dialogView.findViewById(R.id.date);
        TextView from = dialogView.findViewById(R.id.from);
        TextView to = dialogView.findViewById(R.id.to);
        TextView flightNumber = dialogView.findViewById(R.id.flightNumber);
        TextView seat = dialogView.findViewById(R.id.seat);
        TextView departureTime = dialogView.findViewById(R.id.departureTime);
        TextView arrivalTime = dialogView.findViewById(R.id.arrivalTime);
        TextView passengerNameTextView = dialogView.findViewById(R.id.passengerName); // Correctly find this in dialogView

        // Log the details to check if they are correct
        Log.d("TicketDetails", "Details: " + Arrays.toString(details));

        // Check if details array has the expected length
        if (details.length < 6) {
            Toast.makeText(this, "Ticket details are incomplete.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get passenger name from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("User  Prefs", MODE_PRIVATE);
        String passengerName = prefs.getString("USER_NAME", "Passenger");

        // Populate the views with flight details
        airlineName.setText(details[3]);
        passengerNameTextView.setText("Passenger: " + passengerName);
        from.setText(details[1]);
        to.setText(details[2]);
        flightNumber.setText(details[0]);
        departureTime.setText(details[4]);
        arrivalTime.setText(details[5]);

        // Build and show the dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setPositiveButton("Close", (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
package com.example.amadeustravelapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.amadeustravelapp.R;
import com.example.amadeustravelapp.adapters.FlightAdapter;
import com.example.amadeustravelapp.classes.Flight;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class flightSearchActivity  extends AppCompatActivity implements TicketPurchaseListener{
    private static final String TAG = "FlightSearchActivity";
    private List<Flight> flightList = new ArrayList<>();
    private FlightAdapter flightAdapter; // Assuming you have a FlightAdapter
    private String NINJA_API_KEY = "3hHhaYzZUi1nUynWhO78Ew==gGlPJGuHMvcvagee";
    private String FLIGHT_API_KEY = "96c61e1c7aa9e89e8cb0851fc630a35d";
    RecyclerView recyclerViewFlights;
    Button searchFlightBtn;
    EditText fromLocation,toLocation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_search); // Set your layout
        searchFlightBtn = findViewById(R.id.search_button);
        // Initialize RecyclerView
        recyclerViewFlights = findViewById(R.id.recycler_view);
        recyclerViewFlights.setLayoutManager(new LinearLayoutManager(this));
        flightAdapter = new FlightAdapter(flightList,this,this::onTicketPurchased);
        recyclerViewFlights.setAdapter(flightAdapter);
        fromLocation = findViewById(R.id.from_location);
        toLocation = findViewById(R.id.to_location);
        // Get the city names from the intent
        Intent intent = getIntent();
        String fromCity = intent.getStringExtra("FROM_CITY");
        String toCity = intent.getStringExtra("TO_CITY");
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Show back button
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back); // Set back button icon

        // Handle back button click
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
        // If the cities are not null, start fetching flights
        if (fromCity != null && toCity != null) {
            try {
                fetchAirportCodesAndSearchFlights(fromCity, toCity);
            } catch (UnsupportedEncodingException e) {
                Log.e(TAG, "Error encoding city names", e);
                Toast.makeText(this, "Error processing city names", Toast.LENGTH_SHORT).show();
            }
        }

        // Set OnClickListener for the search button
        searchFlightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fromCity = fromLocation.getText().toString().trim();
                String toCity = toLocation.getText().toString().trim();

                // Validate input
                if (fromCity.isEmpty() || toCity.isEmpty()) {
                    Toast.makeText(flightSearchActivity.this, "Please enter both locations.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Start fetching airport codes and searching flights
                try {
                    fetchAirportCodesAndSearchFlights(fromCity, toCity);
                } catch (UnsupportedEncodingException e) {
                    Log.e(TAG, "Error encoding city names", e);
                    Toast.makeText(flightSearchActivity.this, "Error processing city names", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void fetchAirportCodesAndSearchFlights(String fromCity, String toCity) throws UnsupportedEncodingException {
        RequestQueue queue = Volley.newRequestQueue(this);

        fetchAirportCode(queue, fromCity, fromCode -> {
            try {
                fetchAirportCode(queue, toCity, toCode -> searchFlights(fromCode, toCode));
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public void onTicketPurchased() {
        // Handle the ticket purchase notification here
        // For example, you can refresh the flight list or show a message
        Toast.makeText(this, "Ticket purchased successfully!", Toast.LENGTH_SHORT).show();
    }
    private void fetchAirportCode(RequestQueue queue, String cityName, AirportCodeCallback callback) throws UnsupportedEncodingException {
        String url = "https://api.api-ninjas.com/v1/airports?name=" + URLEncoder.encode(cityName, "UTF-8");

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        if (response.length() > 0) {
                            JSONObject airportData = response.getJSONObject(0);
                            String iataCode = airportData.getString("iata");
                            Log.d(TAG, "Airport Code for " + cityName + ": " + iataCode);
                            callback.onCodeReceived(iataCode);
                        } else {
                            Toast.makeText(this, "No airport found for: " + cityName, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "Error parsing airport data for: " + cityName, e);
                        Toast.makeText(this, "Error processing airport data for: " + cityName, Toast.LENGTH_SHORT).show();
                    } catch (UnsupportedEncodingException e) {
                        throw new RuntimeException(e);
                    }
                },
                error -> {
                    Log.e(TAG, "Error fetching airport code for: " + cityName, error);
                    Toast.makeText(this, "Error fetching airport code for: " + cityName, Toast.LENGTH_SHORT).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("X-Api-Key", NINJA_API_KEY);
                return headers;
            }
        };

        queue.add(request);
    }

    private void searchFlights(String fromCode, String toCode) {
        String url = "http://api.aviationstack.com/v1/flights?access_key=" + FLIGHT_API_KEY + "&dep_iata=" + fromCode + "&arr_iata=" + toCode;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray flights = response.getJSONArray("data");
                        flightList.clear();
                        if (flights.length() == 0) {
                            Toast.makeText(this, "No flights found for the selected route.", Toast.LENGTH_SHORT).show();
                        } else {
                            for (int i = 0; i < flights.length(); i++) {
                                JSONObject flight = flights.getJSONObject(i);
                                String flightNumber = flight.getJSONObject("flight").getString("number");
                                String departureAirport = flight.getJSONObject("departure").getString("airport");
                                String arrivalAirport = flight.getJSONObject("arrival").getString("airport");
                                String airlineName = flight.optJSONObject("airline") != null ? flight.getJSONObject("airline").optString("name", "N/A") : "N/A";

                                // Get scheduled departure and arrival times
                                String scheduledDeparture = flight.getJSONObject("departure").getString("scheduled");
                                String scheduledArrival = flight.getJSONObject("arrival").getString("scheduled");
                                // Format date and time
                                String formattedDeparture = formatDateTime(scheduledDeparture);
                                String formattedArrival = formatDateTime(scheduledArrival);

                                // Calculate flight duration (string)
                                String duration = calculateDuration(scheduledDeparture, scheduledArrival);

                                // Extract minutes from duration
                                long durationInMinutes = extractMinutesFromDuration(duration);
                                // Calculate estimated price
                                double estimatedPrice = calculateEstimatedPrice(durationInMinutes);
                                String formattedPrice = String.format("%.2f $", estimatedPrice);

                                // Create Flight object with the duration as a string
                                Flight flightData = new Flight(flightNumber, departureAirport, arrivalAirport, airlineName, duration, formattedPrice, formattedDeparture, formattedArrival);
                                flightList.add(flightData);
                            }
                            flightAdapter.notifyDataSetChanged();
                            Toast.makeText(this, "Flights fetched successfully!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "Error parsing flight data", e);
                        Toast.makeText(this, "Error parsing flight data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e(TAG, "Error fetching flights", error);
                    Toast.makeText(this, "Error fetching flights. Please try again later.", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(this).add(request);
    }

    private String calculateDuration(String departureTime, String arrivalTime) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.getDefault());
            Date departureDate = format.parse(departureTime);
            Date arrivalDate = format.parse(arrivalTime);

            if (departureDate != null && arrivalDate != null) {
                long durationMillis = arrivalDate.getTime() - departureDate.getTime();
                long hours = (durationMillis / (1000 * 60 * 60));
                long minutes = (durationMillis / (1000 * 60)) % 60;
                return hours + " hours and " + minutes + " minutes";
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error parsing date", e);
        }
        return "Duration unavailable"; // Fallback for parsing errors
    }

    private double calculateEstimatedPrice(long durationInMinutes) {
        double basePrice = 100.0; // Base price in dollars
        double pricePerHour = 50.0; // Price per hour in dollars

        // Convert duration from minutes to hours
        double durationInHours = durationInMinutes / 60.0;

        // Calculate estimated price
        return basePrice + (durationInHours * pricePerHour);
    }

    private long extractMinutesFromDuration(String duration) {
        long hours = 0, minutes = 0;

        // Extract hours
        Pattern hoursPattern = Pattern.compile("(\\d+) hours");
        Matcher hoursMatcher = hoursPattern.matcher(duration);
        if (hoursMatcher.find()) {
            hours = Long.parseLong(hoursMatcher.group(1));
        }

        // Extract minutes
        Pattern minutesPattern = Pattern.compile("(\\d+) minutes");
        Matcher minutesMatcher = minutesPattern.matcher(duration);
        if (minutesMatcher.find()) {
            minutes = Long.parseLong(minutesMatcher.group(1));
        }

        return hours * 60 + minutes;
    }

    // Helper method to format date and time
    private String formatDateTime(String dateTime) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            Date date = inputFormat.parse(dateTime);
            if (date != null) {
                return outputFormat.format(date);
            }
        } catch (ParseException e) {
            Log.e(TAG, "Error parsing date", e);
        }
        return "Unavailable";
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed(); // Handle back button click
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}

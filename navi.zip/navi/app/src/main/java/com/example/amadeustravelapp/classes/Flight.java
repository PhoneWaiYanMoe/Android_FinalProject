package com.example.amadeustravelapp.classes;

public class Flight {
    private String flightNumber;
    private String departureAirport;
    private String arrivalAirport;
    private String airlineName;
    private String duration; // Add price attribute
    private String estimatedPrice; // Estimated price in dollars
    private String departureTime;
    private String arrivalTime;

    public Flight(String flightNumber, String departureAirport, String arrivalAirport, String airlineName,String duration,String estimatedPrice,String departureTime, String arrivalTime) {
        this.flightNumber = flightNumber;
        this.departureAirport = departureAirport;
        this.arrivalAirport = arrivalAirport;
        this.airlineName = airlineName;
        this.duration=duration;
        this.estimatedPrice=estimatedPrice;
        this.departureTime=departureTime;
        this.arrivalTime=arrivalTime;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getDepartureAirport() {
        return departureAirport;
    }

    public String getArrivalAirport() {
        return arrivalAirport;
    }

    public String getAirlineName() {
        return airlineName;
    }

    public String getDuration() {
        return duration;
    }

    public String getEstimatedPrice() {
        return estimatedPrice;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }
}

package com.example.amadeustravelapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser ;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DestinationDetailActivity extends AppCompatActivity {

    private ImageView destinationImage, favoriteButton;
    private TextView destinationTitle, destinationDescription, destinationAddress, destinationRating;
    private String destinationTitleString;
    private boolean isFavorite = false;
    private FirebaseUser  currentUser ;
    private DatabaseReference userDatabaseRef, commentsDatabaseRef;
    private ListView commentsListView;
    private CommentsAdapter commentsAdapter;
    private List<String> comments;
    private EditText commentEditText;
    private Button commentButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destination_detail);

        destinationImage = findViewById(R.id.destination_image_detail);
        destinationTitle = findViewById(R.id.destination_title_detail);
        destinationDescription = findViewById(R.id.destination_description_detail);
        destinationAddress = findViewById(R.id.destination_address_detail);
        destinationRating = findViewById(R.id.destination_rating);
        favoriteButton = findViewById(R.id.favorite_button);
        commentsListView = findViewById(R.id.comments_list_view);
        commentEditText = findViewById(R.id.comment_edit_text);
        commentButton = findViewById(R.id.comment_button);

        // Retrieve the data passed from the adapter
        Intent intent = getIntent();
        String imageUrl = intent.getStringExtra("imageUrl");
        destinationTitleString = intent.getStringExtra("title");
        String description = intent.getStringExtra("description");
        String address = intent.getStringExtra("address");
        String rating = intent.getStringExtra("rating");

        // Set the data to views
        destinationTitle.setText(destinationTitleString);
        destinationDescription.setText(description);
        destinationAddress.setText(address);
        destinationRating.setText(rating + " ");
        Glide.with(this).load(imageUrl).into(destinationImage);

        // Initialize Firebase
        currentUser  = FirebaseAuth.getInstance().getCurrentUser ();
        userDatabaseRef = FirebaseDatabase.getInstance().getReference("users").child(currentUser .getUid());
        commentsDatabaseRef = FirebaseDatabase.getInstance().getReference("comments").child(destinationTitleString); // Updated reference

        // Initialize comments list and adapter
        comments = new ArrayList<>();
        commentsAdapter = new CommentsAdapter(this, comments);
        commentsListView.setAdapter(commentsAdapter);

        // Load comments from Firebase
        loadComments();

        // Set up comment button click listener
        commentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String commentText = commentEditText.getText().toString().trim();
                if (!commentText.isEmpty()) {
                    // Create a comment object
                    HashMap<String, String> comment = new HashMap<>();
                    comment.put("user", currentUser .getDisplayName() != null ? currentUser .getDisplayName() : "Anonymous");
                    comment.put("content", commentText);
                    // Push the comment to Firebase under the new structure
                    commentsDatabaseRef.push().setValue(comment).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(DestinationDetailActivity.this, "Comment added", Toast.LENGTH_SHORT).show();
                            commentEditText.setText(""); // Clear the input field
                        } else {
                            Toast.makeText(DestinationDetailActivity.this, "Failed to add comment", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(DestinationDetailActivity.this, "Comment cannot be empty", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Check if the destination is already a favorite
        userDatabaseRef.child("favoritePlaces").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    List<String> favoritePlaces = new ArrayList<>();
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        favoritePlaces.add(childSnapshot.getValue(String.class));
                    }
                    if (favoritePlaces.contains(destinationTitleString)) {
                        isFavorite = true;
                        favoriteButton.setImageResource(R.drawable.favorite_on);
                    } else {
                        isFavorite = false;
                        favoriteButton.setImageResource(R.drawable.favorite_off);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DestinationDetailActivity.this, "Failed to load favorite places", Toast.LENGTH_SHORT).show();
            }
        });

        // Set favorite button click listener
        favoriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFavorite) {
                    // Remove destination from favorite places
                    userDatabaseRef.child("favoritePlaces").child(destinationTitleString).removeValue();
                    isFavorite = false;
                    favoriteButton.setImageResource(R.drawable.favorite_off);
                } else {
                    // Add destination to favorite places
                    userDatabaseRef.child("favoritePlaces").child(destinationTitleString).setValue(destinationTitleString);
                    isFavorite = true;
                    favoriteButton.setImageResource(R.drawable.favorite_on);
                }
            }
        });
    }

    private void loadComments() {
        commentsDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                comments.clear(); // Clear the existing comments
                for (DataSnapshot commentSnapshot : snapshot.getChildren()) {
                    String user = commentSnapshot.child("user").getValue(String.class);
                    String content = commentSnapshot.child("content").getValue(String.class);
                    if (user != null && content != null) {
                        comments.add(user + ": " + content); // Format the comment
                    }
                }
                commentsAdapter.notifyDataSetChanged(); // Notify the adapter to refresh the list
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DestinationDetailActivity.this, "Failed to load comments", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

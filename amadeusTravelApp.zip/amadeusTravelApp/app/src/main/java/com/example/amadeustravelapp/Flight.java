package com.example.amadeustravelapp;

public class Flight {
    private String flightNumber;
    private String departureAirport;
    private String arrivalAirport;
    private String date;

    public Flight(String flightNumber, String departureAirport, String arrivalAirport, String date) {
        this.flightNumber = flightNumber;
        this.departureAirport = departureAirport;
        this.arrivalAirport = arrivalAirport;
        this.date = date;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getDepartureAirport() {
        return departureAirport;
    }

    public String getArrivalAirport() {
        return arrivalAirport;
    }

    public String getDate() {
        return date;
    }
}

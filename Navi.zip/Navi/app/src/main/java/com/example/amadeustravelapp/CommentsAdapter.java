package com.example.amadeustravelapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

public class CommentsAdapter extends ArrayAdapter<String> {

    private final Context context;
    private final List<String> comments;

    public CommentsAdapter(Context context, List<String> comments) {
        super(context, R.layout.comment_item, comments);
        this.context = context;
        this.comments = comments;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        // Inflate the layout for each comment item
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.comment_item, parent, false);
        }

        // Get the TextView for displaying the comment
        TextView commentTextView = convertView.findViewById(R.id.commentTextView);

        // Set the comment text
        commentTextView.setText(comments.get(position));

        return convertView;
    }
}

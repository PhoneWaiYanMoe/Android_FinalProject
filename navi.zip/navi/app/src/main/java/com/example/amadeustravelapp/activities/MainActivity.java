package com.example.amadeustravelapp.activities;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.amadeustravelapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser ;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the Floating Action Button
        FloatingActionButton userMenuButton = findViewById(R.id.user_menu);
        userMenuButton.setOnClickListener(this::showUserMenu);
    }

    private void showUserMenu(View view) {
        FirebaseUser  user = FirebaseAuth.getInstance().getCurrentUser ();

        if (user != null) {
            // Fetch the user's display name from Firebase
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(user.getUid());
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String userName = "User "; // Default name
                    if (snapshot.exists()) {
                        userName = snapshot.child("displayName").getValue(String.class);
                        Log.d("User  Data", "Fetched displayName from Firebase: " + userName);
                        SharedPreferences prefs = getSharedPreferences("User  Prefs", MODE_PRIVATE);
                        prefs.edit().putString("USER_NAME", userName).apply();
                        Log.d("User  Prefs", "Stored USER_NAME: " + userName);
                        if (userName == null || userName.isEmpty()) {
                            userName = user.getEmail(); // Fallback to email if display name is not available
                        }
                    }

                    // Create the PopupMenu and anchor it to the user menu button
                    PopupMenu popupMenu = new PopupMenu(MainActivity.this, view);
                    popupMenu.getMenuInflater().inflate(R.menu.user_menu, popupMenu.getMenu());

                    // Set the title of the first menu item to the user's name
                    popupMenu.getMenu().getItem(0).setTitle(userName);

                    popupMenu.setOnMenuItemClickListener(item -> {
                        if (item.getItemId() == R.id.logout) {
                            FirebaseAuth.getInstance().signOut();
                            Toast.makeText(MainActivity.this, "Logged out", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                            startActivity(intent);
                            finish();
                            return true;
                        } else if (item.getItemId() == R.id.user_profile) {
                            Intent intent = new Intent(MainActivity.this, UserProfileActivity.class);
                            startActivity(intent);
                            return true;
                        }
                        return false;
                    });

                    // Show the popup menu
                    popupMenu.show();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.e(TAG, "Failed to load user info: " + error.getMessage());
                }
            });
        } else {
            // Handle the case where the user is not logged in
            Toast.makeText(MainActivity.this, "User  not logged in", Toast.LENGTH_SHORT).show();
        }
    }
}
package com.example.amadeustravelapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.amadeustravelapp.classes.Destination;
import com.example.amadeustravelapp.activities.DestinationDetailActivity;
import com.example.amadeustravelapp.R;

import java.util.List;

public class RecommendedDestinationsAdapter extends RecyclerView.Adapter<RecommendedDestinationsAdapter.DestinationViewHolder> {
    private Context context;
    private List<Destination> destinationsList;

    public RecommendedDestinationsAdapter(Context context, List<Destination> destinationsList) {
        this.context = context;
        this.destinationsList = destinationsList;
    }

    @NonNull
    @Override
    public DestinationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_recommended_destination, parent, false);
        return new DestinationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DestinationViewHolder holder, int position) {
        Destination destination = destinationsList.get(position);
        holder.title.setText(destination.getTitle());
        holder.address.setText(destination.getAddress());
        holder.rating.setText(String.valueOf(destination.getRating()) + " ⭐");

        // Load the image using Glide
        Glide.with(context)
                .load(destination.getImageUrl())
                .placeholder(R.drawable.placeholder) // Replace with your placeholder image
                .into(holder.image);

        // Set click listener to open details
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DestinationDetailActivity.class);
            intent.putExtra("imageUrl", destination.getImageUrl());
            intent.putExtra("title", destination.getTitle());
            intent.putExtra("description", destination.getDescription());
            intent.putExtra("address", destination.getAddress());
            intent.putExtra("rating", String.valueOf(destination.getRating()));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return destinationsList.size();
    }

    public static class DestinationViewHolder extends RecyclerView.ViewHolder {
        TextView title, address, rating;
        ImageView image;

        public DestinationViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.destination_title);
            address = itemView.findViewById(R.id.destination_address);
            rating = itemView.findViewById(R.id.destination_rating);
            image = itemView.findViewById(R.id.destination_image);
        }
    }
}
package com.example.amadeustravelapp.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.amadeustravelapp.R;
import com.example.amadeustravelapp.adapters.CommentsAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser ;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DestinationDetailActivity extends AppCompatActivity {

    private ImageView destinationImage, favoriteButton, sendCommentButton, backButton;
    private TextView destinationTitle, destinationDescription, destinationAddress, destinationRating;
    private EditText commentEditText;
    private RecyclerView commentsRecyclerView;

    private String destinationTitleString;
    private boolean isFavorite = false;

    private FirebaseUser  currentUser ;
    private DatabaseReference userDatabaseRef, commentsDatabaseRef;

    private CommentsAdapter commentsAdapter;
    private List<String> comments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destination_detail);

        initializeViews();
        retrieveIntentData();
        initializeFirebase();
        setupRecyclerView();
        loadComments();

        sendCommentButton.setOnClickListener(v -> sendComment());
        backButton.setOnClickListener(v -> finish());
        favoriteButton.setOnClickListener(v -> toggleFavorite());
    }

    private void initializeViews() {
        destinationImage = findViewById(R.id.destination_image_detail);
        favoriteButton = findViewById(R.id.favorite_button);
        sendCommentButton = findViewById(R.id.comment_button);
        destinationTitle = findViewById(R.id.destination_title_detail);
        destinationDescription = findViewById(R.id.destination_description_detail);
        destinationAddress = findViewById(R.id.destination_address_detail);
        destinationRating = findViewById(R.id.destination_rating);
        commentsRecyclerView = findViewById(R.id.comments_recycler_view);
        commentEditText = findViewById(R.id.comment_edit_text);
        backButton = findViewById(R.id.back_button);
    }

    private void retrieveIntentData() {
        destinationTitleString = getIntent().getStringExtra("title");
        String imageUrl = getIntent().getStringExtra("imageUrl");
        String description = getIntent().getStringExtra("description");
        String address = getIntent().getStringExtra("address");
        String rating = getIntent().getStringExtra("rating");

        destinationTitle.setText(destinationTitleString);
        destinationDescription.setText(description);
        destinationAddress.setText(address);
        destinationRating.setText(rating + " ");
        Glide.with(this).load(imageUrl).into(destinationImage);
    }

    private void initializeFirebase() {
        currentUser  = FirebaseAuth.getInstance().getCurrentUser ();
        userDatabaseRef = FirebaseDatabase.getInstance().getReference("users").child(currentUser .getUid());
        commentsDatabaseRef = FirebaseDatabase.getInstance().getReference("comments").child(destinationTitleString);
    }

    private void setupRecyclerView() {
        comments = new ArrayList<>();
        commentsAdapter = new CommentsAdapter(this, comments);
        commentsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        commentsRecyclerView.setAdapter(commentsAdapter);
    }

    private void sendComment() {
        String commentText = commentEditText.getText().toString().trim();
        if (commentText.isEmpty()) {
            Toast.makeText(this, "Comment cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        userDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String userName = snapshot.child("displayName").getValue(String.class);
                if (userName == null || userName.isEmpty()) {
                    userName = currentUser .getEmail();
                }

                HashMap<String, String> comment = new HashMap<>();
                comment.put("user", userName);
                comment.put("content", commentText);

                commentsDatabaseRef.push().setValue(comment).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(DestinationDetailActivity.this, "Comment added", Toast.LENGTH_SHORT).show();
                        commentEditText.setText("");
                        loadComments(); // Reload comments to show the new one
                    } else {
                        Toast.makeText(DestinationDetailActivity.this, "Failed to add comment", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DestinationDetailActivity.this, "Failed to fetch user data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void toggleFavorite() {
        if (isFavorite) {
            userDatabaseRef.child("favoritePlaces").child(destinationTitleString).removeValue();
            favoriteButton.setImageResource(R.drawable.favorite_off);
        } else {
            userDatabaseRef.child("favoritePlaces").child(destinationTitleString).setValue(destinationTitleString);
            favoriteButton.setImageResource(R.drawable.favorite_on);
        }
        isFavorite = !isFavorite;
    }

    private void loadComments() {
        commentsDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                comments.clear();
                for (DataSnapshot commentSnapshot : snapshot.getChildren()) {
                    String user = commentSnapshot.child("user").getValue(String.class);
                    String content = commentSnapshot.child("content").getValue(String.class);

                    if (user != null && content != null) {
                        comments.add(user + ": " + content);
                    }
                }
                commentsAdapter.notifyDataSetChanged();
                commentsRecyclerView.scrollToPosition(comments.size() - 1); // Scroll to the latest comment
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DestinationDetailActivity.this, "Failed to load comments", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
package com.example.amadeustravelapp.activities;

public interface TicketPurchaseListener {
    void onTicketPurchased();
}
